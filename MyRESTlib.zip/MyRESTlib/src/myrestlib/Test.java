/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myrestlib;

import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.MongoClient;

/**
 *
 * @author M6000628
 */
public class Test {
    public static void main(String args[])
    {
        MongoClient cli=Connectiontomongodb.connect();
        DB db=cli.getDB("project");
        DBCollection paths= db.getCollection("paths");
       paths.drop();
        DBCollection delpath=db.getCollection("fdelpath");
        delpath.drop();
        
    }  
}
