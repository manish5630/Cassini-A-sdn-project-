/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myrestlib;

import com.mongodb.util.JSON;
import org.json.JSONObject;

/**
 *
 * @author M6000628
 */
public class Odlfunctions {
    public static String deleteflow()
    {
        String res="call successfull";
       // System.out.println("jhgjhjhjhdhjjhdjhd");
        /* MyRESTlib mylib=new MyRESTlib();
        String myurl="http://172.16.52.140:8181/restconf/config/opendaylight-inventory:nodes/node/openflow:1/table/0/flow/19";
       int flowid= mylib.myDeleteRequest(myurl);
       System.out.println("flow deleted id: "+flowid);*/
        return res;
    }
    
}
