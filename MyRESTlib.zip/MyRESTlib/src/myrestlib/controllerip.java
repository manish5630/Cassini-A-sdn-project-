/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myrestlib;

/**
 *
 * @author M6000628
 */
public class controllerip {
    public static String controllerip="http://172.16.52.74:8181";
    
}
